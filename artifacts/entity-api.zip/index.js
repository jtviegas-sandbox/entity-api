'use strict';

const service = require('@jtviegas/entity-service');

exports.handler = (event, context, callback) => {

    service.handler(event, context, callback);

}

